# Responsive demonstration

Code to accompany the **responsive design** video.

Includes the [width demo](width) ([live site](https://ctec3905-2022.github.io/responsive-design-demos/width)) and the [main kitten site](demo) ([live site](https://ctec3905-2022.github.io/responsive-design-demos/demo)) demo.
