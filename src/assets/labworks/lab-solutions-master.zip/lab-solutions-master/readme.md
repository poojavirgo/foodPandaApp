# CTEC3905 lab solutions

This is a repository which contains solutions to lab exercises.

- [Lab 1: Getting started](lab-01)
([live version](https://ctec3905-2022.github.io/lab-solutions/lab-01/))
- [Lab 2: A bit more of everything](lab-02)
([live version](https://ctec3905-2022.github.io/lab-solutions/lab-02/))
- [Lab 4: A responsive menu](lab-04)
([live version](https://ctec3905-2022.github.io/lab-solutions/lab-04/))
- [Lab 5: Getting user input](lab-05)
([live version](https://ctec3905-2022.github.io/lab-solutions/lab-05/))
- [Lab 6: Working with data](lab-06)
([live version](https://ctec3905-2022.github.io/lab-solutions/lab-06/))
- [Lab 7: Getting data from APIs](lab-07)
([live version](https://ctec3905-2022.github.io/lab-solutions/lab-07/))
