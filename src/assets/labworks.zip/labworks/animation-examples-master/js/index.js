clickable.addEventListener('click', ev => {
	clickable.classList.toggle("clicked");
});
